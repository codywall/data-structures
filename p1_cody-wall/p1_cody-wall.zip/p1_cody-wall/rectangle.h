//
// Created by Cody Wall on 2019-09-30.
//

#ifndef CSIS45_RECTANGLE_H
#define CSIS45_RECTANGLE_H
void area(float width, float height);
void perimeter(float width, float height);
#endif //CSIS45_RECTANGLE_H
