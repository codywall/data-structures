//
// Created by Cody Wall on 2019-09-30.
//

#ifndef CSIS45_HEADER_H
#define CSIS45_HEADER_H

void show(int num);

#endif //CSIS45_HEADER_H
