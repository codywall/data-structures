//
// Created by Cody Wall on 2019-09-30.
//

#ifndef CSIS45_HEADER2_H
#define CSIS45_HEADER2_H
void show2(int num);
#endif //CSIS45_HEADER2_H
