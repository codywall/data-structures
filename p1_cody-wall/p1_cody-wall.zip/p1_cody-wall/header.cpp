//
// Created by Cody Wall on 2019-09-30.
//

#include <iostream>
using namespace std;

void show(int num)
{
    cout << "num = " << num << endl;
}
