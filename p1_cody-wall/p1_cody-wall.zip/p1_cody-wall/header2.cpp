//
// Created by Cody Wall on 2019-09-30.
//

#include "header.h"

void show2(int num)
{
    show(num);
}
